package com.shan.mq.consumer.service;

import com.shan.mq.consumer.schema.TradeMessage;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Slf4j
@Service
public class ConsumerService {

    private static int COUNTER_NUM = 1;
    private final ExecutorService executorService;

    public ConsumerService() {
        this.executorService = Executors.newFixedThreadPool(10); // Adjust thread pool size
    }
//
//        @KafkaListener(topics = "trade", groupId = "${spring.kafka.consumer.group-id}")
//    public void consumeTradeMessage(ConsumerRecord<String, String> record) {
//        executorService.submit(() -> {
//            processMessage(record.value());
//        });
//    }
    @KafkaListener(topics = "${spring.kafka.consumer.topic}",
            groupId = "${spring.kafka.consumer.group-id}")
    public void consumeMessage(String tradeMessage) {
        COUNTER_NUM++;
        System.out.println("Thread: " + Thread.currentThread().getName() + " - Counter: " + COUNTER_NUM);
    }

    private void processMessage(String message) {
        // Process the message
        System.out.println("Consumed message: " + message);
    }
}

