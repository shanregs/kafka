package com.shan.mq.producer.service;

import com.shan.mq.producer.schema.TradeMessage;
import com.shan.mq.producer.util.TradeMessageGenerator;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

@Slf4j
@Service
public class ProducerService {


    private final KafkaTemplate<String, String> kafkaTemplate;
    private static final int TOTAL_MESSAGES = 100000;  // Total messages to be sent
    private static final int PARTITIONS = 10;          // Number of Kafka partitions
    private static final int MESSAGES_PER_SEC = 300;   // Target messages per second
    private static final int THREADS = PARTITIONS;     // Number of producer threads (one per partition)

    private ExecutorService executorService;

    public ProducerService(KafkaTemplate<String, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    @PostConstruct
    public void init() {
        // Initialize the ExecutorService with a thread pool equal to the number of partitions
        this.executorService = Executors.newFixedThreadPool(THREADS);
    }

    public void sendMessagesBatch() {
        AtomicInteger messageCounter = new AtomicInteger(0);

        // Submit tasks for each partition
        for (int partition = 0; partition < PARTITIONS; partition++) {
            int finalPartition = partition;
            executorService.submit(() -> sendMessagesToPartition_v1(finalPartition, messageCounter));
        }
    }

    private void sendMessagesToPartition_v1(int partition, AtomicInteger messageCounter) {
        long startTime = System.currentTimeMillis();
        int messagesSent = 0;
        while (messageCounter.get() < 2_000_000) {
//            TradeMessage message = TradeMessageGenerator.generateTradeMessage();
            String payload = TradeMessageGenerator.generateTradeMessage().getName();
            String key = "key-" + messageCounter.get() % PARTITIONS;
//            System.out.println("Key : "+ key + " . thread : " +  Thread.currentThread().getName());
            if (messageCounter.get()  % 10000 == 0) {  // Log progress for every 1000 messages
                System.out.println("Sent " + (messageCounter.get()  + 1) + " messages  - " +  Thread.currentThread().getName());
            }
            kafkaTemplate.send("trade", partition, key, payload);
            messageCounter.incrementAndGet();
        }
//        System.out.println("END -- Sent all messages");
        long endTime = System.currentTimeMillis();  // End time after the loop finishes
        long elapsedTime = endTime - startTime;  // Elapsed time in milliseconds
        System.out.println("END -- Sent all messages in " + convertMillisToMinutesSeconds(elapsedTime) + " ms");
    }
    public static String convertMillisToMinutesSeconds(long elapsedTimeMillis) {
        long minutes = elapsedTimeMillis / 60000;  // 1 minute = 60000 milliseconds
        long seconds = (elapsedTimeMillis % 60000) / 1000;  // Remaining seconds
        long milliseconds = elapsedTimeMillis % 1000;  // Remaining milliseconds

        return String.format("%d minutes %d seconds %d milliseconds", minutes, seconds, milliseconds);
    }
    private void sendMessagesToPartition(int partition, AtomicInteger messageCounter) {
        long startTime = System.currentTimeMillis();
        int messagesSent = 0;
        System.out.println("Going to send all messages");
        while (messageCounter.get() < TOTAL_MESSAGES) {
            TradeMessage message = TradeMessageGenerator.generateTradeMessage();
            kafkaTemplate.send("trade", partition, "key-" + messageCounter.get(), message.getName());
            messageCounter.incrementAndGet();
            messagesSent++;

            // Ensure the rate of messages does not exceed the target (300 messages/sec)
            if (messagesSent >= (MESSAGES_PER_SEC / PARTITIONS)) {
                long elapsed = System.currentTimeMillis() - startTime;
                if (elapsed < 1000) {
                    try {
                        Thread.sleep(1000 - elapsed); // Sleep only to balance the rate
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                }
                messagesSent = 0;
                startTime = System.currentTimeMillis();
            }
        }
        System.out.println("END -- Sent all messages");
    }

    public void sendSingleMessage() {
        String message = TradeMessageGenerator.generateTradeMessage().getName();
        ProducerRecord<String, String> record = new ProducerRecord<>("trade", "key", message);

        // Send the message
        kafkaTemplate.send("trade", 1, "key-" + 1, message);
    }
}
