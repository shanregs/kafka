package com.shan.mq.producer.util;

import com.github.javafaker.Faker;
import com.shan.mq.producer.schema.TradeMessage;

import java.time.Instant;

public class TradeMessageGenerator {

    private static final Faker faker = new Faker();  // Faker instance to generate fake data

    public static TradeMessage generateTradeMessage() {
        // Create a new TradeMessage instance
        TradeMessage message = new TradeMessage();

        // Set sendtime to current timestamp
        message.setSendtime(Instant.now().toString());

        // Generate data using Faker
        String name = faker.name().fullName();
        String address = faker.address().fullAddress();
        String creditCardNumber = faker.finance().creditCard();
        String phoneNumber = faker.phoneNumber().phoneNumber();
        String email = faker.internet().emailAddress();
        String transactionId = faker.commerce().promotionCode();

        // Set generated data in the message object
        message.setName(name);
        message.setAddress(address);
        message.setCreditCardNumber(creditCardNumber);
        message.setPhoneNumber(phoneNumber);
        message.setEmail(email);
        message.setTransactionId(transactionId);

        // Generate dummy data for the 'data' field and ensure it is 2KB
        String dummyData = faker.lorem().paragraph(5);  // Random paragraph
        byte[] data = dummyData.getBytes();  // Convert to bytes

        // Ensure byte array is 2KB (2048 bytes)
        byte[] paddedData = new byte[2048];
        System.arraycopy(data, 0, paddedData, 0, Math.min(data.length, paddedData.length));
        message.setData(paddedData);

        return message;
    }
}
