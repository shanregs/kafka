package com.shan.mq.producer.controller;



import com.shan.mq.producer.service.ProducerService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Slf4j
@RestController
@RequestMapping("/api/produce")
public class ProducerController {

    private final ProducerService producerService;
    private final ExecutorService executorService;

    @Autowired
    public ProducerController(ProducerService producerService) {
        this.producerService = producerService;
        this.executorService = Executors.newSingleThreadExecutor();
    }
    @GetMapping("/send-single-message")
    public String sendSingleMessage() {
        try {
            // Send a single message via the producer service
            producerService.sendSingleMessage();
            return "Single message sent successfully.";
        } catch (Exception e) {
            return "Error while sending the message: " + e.getMessage();
        }
    }
    @GetMapping("/sendmsg")
    public String startProducingMessages() {
        System.out.println("Going to send messaeges");
        executorService.submit(() -> {
            try {
                producerService.sendMessagesBatch();
            } catch (Exception e) {
                Thread.currentThread().interrupt();
            }
        });
        return "Message production started. 300 messages per second for 1 lakh messages.";
    }
}
