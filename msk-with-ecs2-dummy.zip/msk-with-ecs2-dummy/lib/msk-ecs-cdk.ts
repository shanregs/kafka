#!/usr/bin/env node
import 'source-map-support/register';
import * as cdk from 'aws-cdk-lib';
import { VpcStack } from '../lib/vpc-stack';
import { KmsStack } from '../lib/kms-stack';
import { MskStack } from '../lib/msk-stack';
import { EcrStack } from '../lib/ecr-stack';
import { EcsStack } from '../lib/ecs-stack';
import { BastionStack } from '../lib/bastion-stack'

const app = new cdk.App();

// Deploy KMS stack first
const kmsStack = new KmsStack(app, 'KmsStack', { env: { region: 'us-east-1' } });

// Load KMS ARNs from environment (manually set after KmsStack deployment)
const mskDataKmsKeyArn = process.env.MSK_DATA_KMS_KEY_ARN || 'arn:aws:kms:us-east-1:ACCOUNT_ID:key/placeholder-msk-data';
const mskLogsKmsKeyArn = process.env.MSK_LOGS_KMS_KEY_ARN || 'arn:aws:kms:us-east-1:ACCOUNT_ID:key/placeholder-msk-logs';
const ecsLogsKmsKeyArn = process.env.ECS_LOGS_KMS_KEY_ARN || 'arn:aws:kms:us-east-1:ACCOUNT_ID:key/placeholder-ecs-logs';

const vpcStack = new VpcStack(app, 'VpcStack', { env: { region: 'us-east-1' } });
const mskStack = new MskStack(app, 'MskStack', vpcStack.vpc, mskDataKmsKeyArn, mskLogsKmsKeyArn, { env: { region: 'us-east-1' } });
const ecrStack = new EcrStack(app, 'EcrStack', { env: { region: 'us-east-1' } });
const ecsStack = new EcsStack(app, 'EcsStack', vpcStack.vpc, mskStack, ecrStack, ecsLogsKmsKeyArn, { env: { region: 'us-east-1' } });
const bastionStack = new BastionStack(app, 'BastionStack', vpcStack.vpc, mskStack, { env: { region: 'us-east-1' } });

mskStack.addDependency(vpcStack);
mskStack.addDependency(kmsStack);
ecsStack.addDependency(vpcStack);
ecsStack.addDependency(mskStack);
ecsStack.addDependency(ecrStack);
ecsStack.addDependency(kmsStack);
bastionStack.addDependency(vpcStack);
bastionStack.addDependency(mskStack);