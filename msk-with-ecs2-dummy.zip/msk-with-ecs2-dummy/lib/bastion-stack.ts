import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as iam from 'aws-cdk-lib/aws-iam';
import { MskStack } from './msk-stack';

export class BastionStack extends cdk.Stack {
  constructor(scope: Construct, id: string, vpc: ec2.IVpc, mskStack: MskStack, props?: cdk.StackProps) {
    super(scope, id, props);

    const mskSecurityGroup = mskStack.mskSecurityGroup;

    const bastionSecurityGroup = new ec2.SecurityGroup(this, 'RdpBastionSecurityGroup', {
      vpc,
      securityGroupName: 'rdp-bastion-sg',
      description: 'Security group for bastion host',
      allowAllOutbound: true,
    });

    const mskPorts = [9098, 2181];
    mskPorts.forEach((port) => {
      mskSecurityGroup.addIngressRule(
        bastionSecurityGroup,
        ec2.Port.tcp(port),
        `Allow port ${port} from bastion host`
      );
    });

    const bastionHost = new ec2.BastionHostLinux(this, 'RdpBastionHost', {
      vpc,
      subnetSelection: { subnetType: ec2.SubnetType.PUBLIC },
      instanceName: 'rdp-bastion',
      securityGroup: bastionSecurityGroup,
    });

    const mskPolicyStatement = new iam.PolicyStatement({
      actions: ['kafka:*'],
      resources: [mskStack.mskClusterArn],
    });
    bastionHost.instance.role.addToPrincipalPolicy(mskPolicyStatement);

    new cdk.CfnOutput(this, 'BastionHostPublicIp', { value: bastionHost.instancePublicIp });
  }
}