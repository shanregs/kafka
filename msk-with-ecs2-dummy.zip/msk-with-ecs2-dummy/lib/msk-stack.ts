import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as msk from 'aws-cdk-lib/aws-msk';
import * as kms from 'aws-cdk-lib/aws-kms';
import * as logs from 'aws-cdk-lib/aws-logs';

export class MskStack extends cdk.Stack {
  public readonly mskSecurityGroup: ec2.SecurityGroup;
  public readonly mskClusterArn: string;

  constructor(scope: Construct, id: string, vpc: ec2.IVpc, mskDataKmsKeyArn: string, mskLogsKmsKeyArn: string, props?: cdk.StackProps) {
    super(scope, id, props);

    this.mskSecurityGroup = new ec2.SecurityGroup(this, 'RdpMskSecurityGroup', {
      vpc,
      securityGroupName: 'rdp-msk-sg',
      description: 'Security group for rdp-msk-cluster',
      allowAllOutbound: true,
    });

    const mskPorts = [9098, 2181];
    mskPorts.forEach((port) => {
      this.mskSecurityGroup.addIngressRule(
        this.mskSecurityGroup,
        ec2.Port.tcp(port),
        `Allow port ${port} for MSK internal communication`
      );
    });

    // Lookup KMS keys using ARNs from environment or outputs
    const mskDataKmsKey = kms.Key.fromKeyArn(this, 'RdpMskDataKmsKeyLookup', mskDataKmsKeyArn);
    const mskLogsKmsKey = kms.Key.fromKeyArn(this, 'RdpMskLogsKmsKeyLookup', mskLogsKmsKeyArn);

    // Lookup or create CloudWatch log group for MSK
    let logGroup: logs.ILogGroup;
    const logGroupName = 'rdp-msk-logs';
    logGroup = logs.LogGroup.fromLogGroupName(this, 'RdpMskLogGroupLookup', logGroupName);
    if (!logGroup.logGroupArn) {
      logGroup = new logs.LogGroup(this, 'RdpMskLogGroup', {
        logGroupName,
        retention: logs.RetentionDays.ONE_MONTH,
        encryptionKey: mskLogsKmsKey,
        removalPolicy: cdk.RemovalPolicy.RETAIN,
      });
    }

    const mskCluster = new msk.CfnCluster(this, 'RdpMskCluster', {
      clusterName: 'rdp-msk-cluster',
      kafkaVersion: '3.7.x',
      numberOfBrokerNodes: 2,
      brokerNodeGroupInfo: {
        instanceType: 'kafka.t2.small',
        storageInfo: { ebsStorageInfo: { volumeSize: 10 } },
        clientSubnets: vpc.privateSubnets.map((subnet) => subnet.subnetId),
        securityGroups: [this.mskSecurityGroup.securityGroupId],
      },
      encryptionInfo: { encryptionAtRest: { dataVolumeKmsKeyId: mskDataKmsKey.keyId } },
      clientAuthentication: { sasl: { iam: { enabled: true } } },
      loggingInfo: { brokerLogs: { cloudWatchLogs: { enabled: true, logGroup: logGroup.logGroupName } } },
    });

    this.mskClusterArn = mskCluster.attrArn;

    new cdk.CfnOutput(this, 'ClusterArn', { value: this.mskClusterArn });
  }
}