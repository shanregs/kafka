import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as kms from 'aws-cdk-lib/aws-kms';

export class KmsStack extends cdk.Stack {
  public readonly mskDataKmsKey: kms.IKey;
  public readonly mskLogsKmsKey: kms.IKey;
  public readonly ecsLogsKmsKey: kms.IKey;

  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    // KMS Key for MSK Data Encryption
    this.mskDataKmsKey = new kms.Key(this, 'RdpMskDataKmsKey', {
      alias: 'rdp-msk-kms-key',
      description: 'KMS key for MSK data encryption',
      enableKeyRotation: true,
      removalPolicy: cdk.RemovalPolicy.RETAIN,
    });

    // KMS Key for MSK Logs Encryption
    this.mskLogsKmsKey = new kms.Key(this, 'RdpMskLogsKmsKey', {
      alias: 'rdp-cloudwatch-kms-key',
      description: 'KMS key for MSK CloudWatch logs encryption',
      enableKeyRotation: true,
      removalPolicy: cdk.RemovalPolicy.RETAIN,
    });

    // KMS Key for ECS Logs Encryption
    this.ecsLogsKmsKey = new kms.Key(this, 'RdpEcsLogsKmsKey', {
      alias: 'rdp-ecs-logs-kms-key',
      description: 'KMS key for ECS Fargate logs',
      enableKeyRotation: true,
      removalPolicy: cdk.RemovalPolicy.RETAIN,
    });

    // Export ARNs as outputs
    new cdk.CfnOutput(this, 'MskDataKmsKeyArn', { value: this.mskDataKmsKey.keyArn });
    new cdk.CfnOutput(this, 'MskLogsKmsKeyArn', { value: this.mskLogsKmsKey.keyArn });
    new cdk.CfnOutput(this, 'EcsLogsKmsKeyArn', { value: this.ecsLogsKmsKey.keyArn });
  }
}