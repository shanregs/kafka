import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as ecs from 'aws-cdk-lib/aws-ecs';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as kms from 'aws-cdk-lib/aws-kms';
import * as logs from 'aws-cdk-lib/aws-logs';
import { MskStack } from './msk-stack';
import { EcrStack } from './ecr-stack';

export class EcsStack extends cdk.Stack {
  constructor(scope: Construct, id: string, vpc: ec2.IVpc, mskStack: MskStack, ecrStack: EcrStack, ecsLogsKmsKeyArn: string, props?: cdk.StackProps) {
    super(scope, id, props);

    const mskSecurityGroup = mskStack.mskSecurityGroup;

    // Lookup KMS key for ECS logs using ARN
    const ecsLogsKmsKey = kms.Key.fromKeyArn(this, 'RdpEcsLogsKmsKeyLookup', ecsLogsKmsKeyArn);

    // Create or lookup Log Groups for producer and consumer
    const producerLogGroup = logs.LogGroup.fromLogGroupName(this, 'RdpProducerLogGroupLookup', 'rdp-producer-logs') || 
      new logs.LogGroup(this, 'RdpProducerLogGroup', {
        logGroupName: 'rdp-producer-logs',
        retention: cdk.aws_logs.RetentionDays.ONE_MONTH,
        encryptionKey: ecsLogsKmsKey,
        removalPolicy: cdk.RemovalPolicy.RETAIN,
      });

    const consumerLogGroup = logs.LogGroup.fromLogGroupName(this, 'RdpConsumerLogGroupLookup', 'rdp-consumer-logs') || 
      new logs.LogGroup(this, 'RdpConsumerLogGroup', {
        logGroupName: 'rdp-consumer-logs',
        retention: cdk.aws_logs.RetentionDays.ONE_MONTH,
        encryptionKey: ecsLogsKmsKey,
        removalPolicy: cdk.RemovalPolicy.RETAIN,
      });

    const cluster = new ecs.Cluster(this, 'RdpEcsCluster', {
      vpc,
      clusterName: 'rdp-ecs-cluster',
    });

    const mskPolicyStatement = new iam.PolicyStatement({
      actions: ['kafka:*'],
      resources: [mskStack.mskClusterArn],
    });

    const executionPolicyStatement = new iam.PolicyStatement({
      actions: [
        'ecr:GetAuthorizationToken',
        'ecr:BatchCheckLayerAvailability',
        'ecr:GetDownloadUrlForLayer',
        'ecr:BatchGetImage',
        'logs:CreateLogStream',
        'logs:PutLogEvents',
      ],
      resources: ['*'],
    });

    // Producer execution role and task definition
    const producerExecutionRole = new iam.Role(this, 'RdpProducerExecutionRole', {
      assumedBy: new iam.ServicePrincipal('ecs-tasks.amazonaws.com'),
      description: 'Execution role for producer task',
    });
    producerExecutionRole.addToPolicy(executionPolicyStatement);

    const producerTaskDef = new ecs.FargateTaskDefinition(this, 'RdpProducerTaskDef', {
      memoryLimitMiB: 512,
      cpu: 256,
      executionRole: producerExecutionRole,
    });
    producerTaskDef.taskRole.addToPrincipalPolicy(mskPolicyStatement);
    producerTaskDef.addContainer('ProducerContainer', {
      image: ecs.ContainerImage.fromEcrRepository(ecrStack.producerRepo, 'latest'),
      logging: ecs.LogDrivers.awsLogs({
        streamPrefix: 'producer',
        logGroup: producerLogGroup,
      }),
      environment: { MSK_CLUSTER_ARN: mskStack.mskClusterArn },
    });

    // Consumer execution role and task definition
    const consumerExecutionRole = new iam.Role(this, 'RdpConsumerExecutionRole', {
      assumedBy: new iam.ServicePrincipal('ecs-tasks.amazonaws.com'),
      description: 'Execution role for consumer task',
    });
    consumerExecutionRole.addToPolicy(executionPolicyStatement);

    const consumerTaskDef = new ecs.FargateTaskDefinition(this, 'RdpConsumerTaskDef', {
      memoryLimitMiB: 512,
      cpu: 256,
      executionRole: consumerExecutionRole,
    });
    consumerTaskDef.taskRole.addToPrincipalPolicy(mskPolicyStatement);
    consumerTaskDef.addContainer('ConsumerContainer', {
      image: ecs.ContainerImage.fromEcrRepository(ecrStack.consumerRepo, 'latest'),
      logging: ecs.LogDrivers.awsLogs({
        streamPrefix: 'consumer',
        logGroup: consumerLogGroup,
      }),
      environment: { MSK_CLUSTER_ARN: mskStack.mskClusterArn },
    });

    const ecsSecurityGroup = new ec2.SecurityGroup(this, 'RdpEcsSecurityGroup', {
      vpc,
      securityGroupName: 'rdp-ecs-sg',
      description: 'Security group for ECS Fargate services',
      allowAllOutbound: true,
    });

    const mskPorts = [9098, 2181];
    mskPorts.forEach((port) => {
      mskSecurityGroup.addIngressRule(
        ecsSecurityGroup,
        ec2.Port.tcp(port),
        `Allow port ${port} from ECS services`
      );
    });

    new ecs.FargateService(this, 'RdpProducerService', {
      cluster,
      taskDefinition: producerTaskDef,
      desiredCount: 1,
      securityGroups: [ecsSecurityGroup],
      vpcSubnets: { subnetType: ec2.SubnetType.PUBLIC },
    });

    new ecs.FargateService(this, 'RdpConsumerService', {
      cluster,
      taskDefinition: consumerTaskDef,
      desiredCount: 1,
      securityGroups: [ecsSecurityGroup],
      vpcSubnets: { subnetType: ec2.SubnetType.PUBLIC },
    });
  }
}